#!/usr/bin/python
"""OPEN DATA API REST SERVER."""


import bottle
import mongodb
import uuid
import yaml

from bson.json_util import dumps

app = bottle.app()
db_name = 'opendatadb'
db = mongodb.connect(db_name)


@app.hook('after_request')
def enable_cors():
    """Enable cors."""
    headers = bottle.response.headers
    headers['Access-Control-Allow-Origin'] = '*'
    headers['Access-Control-Allow-Methods'] = 'OPTIONS, GET'
    headers['Access-Control-Allow-Headers'] = 'Origin, Accept, Content-Type'


@app.route('/', method=['OPTIONS', 'GET'])
def index():
    """Index."""
    return {"API health status": "OK"}


@app.route('/info/', method=['OPTIONS', 'GET'])
def get_info():
    """
    @api {GET} /info/ API Information
    @apiName Info
    @apiGroup General
    @apiDescription Retrieves general information about the API
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} results General information about the API
    @apiSampleRequest /info/
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/info/
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "request_id": "ad506913-a073-4d23-9f95-388d1c1e2c46",
            "result": "Information!"
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    return {
        'request_id': str(uuid.uuid4()),
        'result': "TO ADD INFO HERE ...!"
    }


@app.route('/meta/<c_name>', method=['OPTIONS', 'GET'])
def get_list(c_name):
    """
    @api {GET} /meta/ API Metadata
    @apiName Metadata
    @apiGroup General
    @apiDescription Retrieves metadata for each collection
    @apiParam {String} c_name Collection name (systems, developers, tasks)
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} results Metadata and information about each collection
    @apiSampleRequest /meta/:c_name
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/meta/systems
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "request_id": "ad506913-a073-4d23-9f95-388d1c1e2c46",
            "result": "Metadata showing information about the systems collection."
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    db2 = mongodb.connect(db_name)
    tmp = c_name + 'metadata'
    res = mongodb.showall(db2, tmp)
    return dumps(res)


@app.route('/dev/<id>', method=['OPTIONS', 'GET'])
def get_devSystems(id):
    """
    @api {GET} /dev/:id Developers Metadata
    @apiName DevMetadata
    @apiGroup General
    @apiDescription Retrieves metadata for each developer
    @apiParam {String} id Developer's ID (dev1, dev2, ... dev6)
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} _id Developer's ID
    @apiSuccess (Success 200) {List} Systems A list of all the systems that this developer was involved in
    @apiSuccess (Success 200) {Number} Num_logs Total number of logs recorded for this developer
    @apiSuccess (Success 200) {Number} Num_diaries Total number of diaries recorded for this developer
    @apiSuccess (Success 200) {Number} Num_thinkaloud Total number of thinkaluds recorded for this developer
    @apiSampleRequest /dev/:id
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/dev/dev1
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "_id": "dev1",
            "Numb_logs": 7,
            "Num_diaries": 17,
            "systems": [ ... ],
            "request_id": "ad506913-a073-4d23-9f95-388d1c1e2c46",
            "Num_thinkaloud": 7,
            "_id": "dev1"
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    a = {"_id": "null"}
    a['_id'] = id
    db2 = mongodb.connect(db_name)
    res = db2.developers.find({"_id": id}, {"systems": 1})
    res = str(dumps(res))[1:-1]
    res = yaml.load(res)
    context = res.copy()
    res2 = db2.developers.find_one({"_id": id}, {"logs": 1})
    tmp = {"Num_logs": sum(len(v) for v in res2.itervalues()) - 4}
    context.update(tmp)
    res3 = db2.developers.find_one({"_id": id}, {"diaries": 1})
    tmp = {"Num_diaries": sum(len(v) for v in res3.itervalues()) - 4}
    context.update(tmp)
    res4 = db2.developers.find_one({"_id": id}, {"thinkaloud": 1})
    tmp = {"Num_thinkaloud": sum(len(v) for v in res4.itervalues()) - 4}
    context.update(tmp)
    tmp = {"request_id": str(uuid.uuid4())}
    context.update(tmp)
    return dumps(context)


@app.route('/dev/<id>/log/<date>', method=['OPTIONS', 'GET'])
def get_devLog(id, date):
    """
    @api {GET} /dev/:id/log/:date Developers LogFile
    @apiName DevLog
    @apiGroup Download
    @apiDescription Download a log file of a developer
    @apiParam {String} id Developer's ID (dev1, dev2, ... dev6)
    @apiParam {String} date Date (YYYY-MM-DD)
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} _id Developer's ID
    @apiSuccess (Success 200) {String} url Download URL for this log
    @apiSampleRequest /dev/:id/log/:date
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/dev/dev1/log/2008-10-17
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "_id": "dev1",
            "request_id": "ad506913-a073-4d23-9f95-388d1c1e2c46",
            "url": [http://...],
            "_id": "dev1"
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    a = {"_id": "null"}
    a['_id'] = id
    db2 = mongodb.connect(db_name)
    c = '$gte'
    res = mongodb.queryrange(db2, date, c)
    if res == "-1":
        return {"item": "not found!"}
    res = str(dumps(res))[1:-1]
    res = yaml.load(res)
    context = res.copy()
    tmp = {"request_id": str(uuid.uuid4())}
    context.update(tmp)
    return dumps(context)


@app.route('/dev/<id>/diary/<date>', method=['OPTIONS', 'GET'])
def get_devDiary(id, date):
    """
    @api {GET} /dev/:id/diary/:date Developers DiaryFile
    @apiName DevDiary
    @apiGroup Download
    @apiDescription Download a diary file of a developer
    @apiParam {String} id Developer's ID (dev1, dev2, ... dev6)
    @apiParam {String} date Date (YYYY-MM-DD)
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} _id Developer's ID
    @apiSuccess (Success 200) {String} url Download URL for this diary
    @apiSampleRequest /dev/:id/diary/:date
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/dev/dev1/diary/2008-10-17
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "_id": "dev1",
            "request_id": "jp509893-a073-4d23-9f95-388d1c1e2c46",
            "url": [http://...],
            "_id": "dev1"
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    a = {"_id": "null"}
    a['_id'] = id
    db2 = mongodb.connect(db_name)
    c = '$gte'
    res = mongodb.queryrange2(db2, date, c)
    if res == "-1":
        return {"item": "not found!"}
    res = str(dumps(res))[1:-1]
    res = yaml.load(res)
    context = res.copy()
    tmp = {"request_id": str(uuid.uuid4())}
    context.update(tmp)
    return dumps(context)


@app.route('/dev/<id>/thinkaloud/<date>', method=['OPTIONS', 'GET'])
def get_devThL(id, date):
    """
    @api {GET} /dev/:id/thinkaloud/:date Developers ThinkaloudFile
    @apiName DevTh
    @apiGroup Download
    @apiDescription Download a thinkaloud file of a developer
    @apiParam {String} id Developer's ID (dev1, dev2, ... dev6)
    @apiParam {String} date Date (YYYY-MM-DD)
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} _id Developer's ID
    @apiSuccess (Success 200) {String} file Download URL for this thinkaloud
    @apiSampleRequest /dev/:id/thinkaloud/:date
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/dev/dev1/thinkaloud/2008-11-07
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "thinkaloud": [
            {
                "date": "2008-11-07",
                "file": "dev1_2008-11-07"
            }
            ],
                "_id": "dev1",
                "request_id": "ea99c971-c167-456d-ba69-bee4afb44efb"
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    a = {"_id": "null"}
    a['_id'] = id
    db2 = mongodb.connect(db_name)
    c = '$gte'
    res = mongodb.queryrange3(db2, date, c)
    if res == "-1":
        return {"item": "not found!"}
    res = str(dumps(res))[1:-1]
    res = yaml.load(res)
    context = res.copy()
    tmp = {"request_id": str(uuid.uuid4())}
    context.update(tmp)
    wanted_keys = ['_id', 'request_id', 'thinkaloud']
    ans = dict((k, context[k]) for k in wanted_keys if k in context)

    print ans["thinkaloud"][1]

    return dumps(ans)


@app.route('/case/<id>', method=['OPTIONS', 'GET'])
def get_showcase(id, date):
    """
    @api {GET} /dev/:id/log/:date Developers LogFile
    @apiName DevLog
    @apiGroup Showcases
    @apiDescription Download a log file of a developer
    @apiParam {String} id Developer's ID (dev1, dev2, ... dev6)
    @apiParam {String} date Date (YYYY-MM-DD)
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} _id Developer's ID
    @apiSuccess (Success 200) {String} url Download URL for this log
    @apiSampleRequest /dev/:id/log/:date
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/dev/dev1/log/2008-10-17
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "_id": "dev1",
            "request_id": "ad506913-a073-4d23-9f95-388d1c1e2c46",
            "url": [http://...],
            "_id": "dev1"
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    a = {"_id": "null"}
    a['_id'] = id
    db2 = mongodb.connect(db_name)
    c = '$gte'
    res = mongodb.queryrange(db2, date, c)
    if res == "-1":
        return {"item": "not found!"}
    res = str(dumps(res))[1:-1]
    res = yaml.load(res)
    context = res.copy()
    tmp = {"request_id": str(uuid.uuid4())}
    context.update(tmp)
    return dumps(context)


@app.route('/experiment/<id>', method=['OPTIONS', 'GET'])
def get_experiment(id, date):
    """
    @api {GET} /dev/:id/log/:date Developers LogFile
    @apiName DevLog
    @apiGroup Experiments
    @apiDescription Download a log file of a developer
    @apiParam {String} id Developer's ID (dev1, dev2, ... dev6)
    @apiParam {String} date Date (YYYY-MM-DD)
    @apiSuccess (Success 200) {UUID} request_id Request unique identifier
    @apiSuccess (Success 200) {String} _id Developer's ID
    @apiSuccess (Success 200) {String} url Download URL for this log
    @apiSampleRequest /dev/:id/log/:date
    @apiExample cURL example
    $ curl -i http://opendata.soccerlab.polymtl.ca:5001/dev/dev1/log/2008-10-17
    @apiSuccessExample {js} Success-Response:
        HTTP/1.0 200 OK
        {
            "_id": "dev1",
            "request_id": "ad506913-a073-4d23-9f95-388d1c1e2c46",
            "url": [http://...],
            "_id": "dev1"
        }
    """
    if bottle.request == 'OPTIONS':
        return {}

    a = {"_id": "null"}
    a['_id'] = id
    db2 = mongodb.connect(db_name)
    c = '$gte'
    res = mongodb.queryrange(db2, date, c)
    if res == "-1":
        return {"item": "not found!"}
    res = str(dumps(res))[1:-1]
    res = yaml.load(res)
    context = res.copy()
    tmp = {"request_id": str(uuid.uuid4())}
    context.update(tmp)
    return dumps(context)


if __name__ == '__main__':
    bottle.run(host='0.0.0.0', port=5001)
